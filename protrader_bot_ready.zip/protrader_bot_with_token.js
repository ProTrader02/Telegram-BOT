
const { Telegraf, Markup } = require('telegraf');
const fs = require('fs');
const translate = require('@vitalets/google-translate-api');

const bot = new Telegraf('8175394476:AAFssZqu2_-aQxjHraecgNnQu2zHZW5Fmic');
const ADMIN_IDS = [5469122433, 1173284868];

// /start komandasi
bot.start(async (ctx) => {
  const user = ctx.from;
  const csvLine = `\n${user.id},${user.username || ''},${user.first_name || ''}`;
  if (!fs.readFileSync('users.csv', 'utf8').includes(user.id.toString())) {
    fs.appendFileSync('users.csv', csvLine);
  }

  await ctx.reply(
    '🇺🇿 <b>ProTrader botiga xush kelibsiz!</b>',
    {
      parse_mode: 'HTML',
      reply_markup: {
        keyboard: [
          ['📊 ProTrader Competition'],
          ['👤 Profil', '💬 Support'],
          ['🌐 Ijtimoiy tarmoqlar', '💱 Valyuta Ayirboshlash']
        ],
        resize_keyboard: true
      }
    }
  );
});

// Profil komandasi (faqat /profil orqali)
bot.command('profil', async (ctx) => {
  const user = ctx.from;
  const message = `
🆔 ID: ${user.id}
👤 Ism: ${user.first_name || 'Nomaʼlum'}
📛 Username: @${user.username || 'yoʻq'}
  `;
  await ctx.reply(message);
});

// Ijtimoiy tarmoqlar
bot.hears('🌐 Ijtimoiy tarmoqlar', (ctx) => {
  return ctx.reply(
    '🔗 Ijtimoiy tarmoqlarimiz:',
    Markup.inlineKeyboard([
      [Markup.button.url('📸 Instagram', 'https://www.instagram.com/protrader.24?igsh=bWhhd2xuaWh5MGo5')],
      [Markup.button.url('🐦 Twitter', 'https://x.com/k_rustamjonov?t=Hk84rHkBwN-HqYfyINsQdQ&s=35')],
      [Markup.button.url('📺 YouTube', 'https://youtube.com/@protrader_frx?si=DuR2U8-2sKqDyVHN')],
      [Markup.button.url('💬 Telegram', 'https://t.me/protrader_fx24')]
    ])
  );
});

// Valyuta Ayirboshlash
bot.hears('💱 Valyuta Ayirboshlash', (ctx) => {
  return ctx.reply('⚙️ Tez orada ishga tushadi

✉️ Admin bilan aloqa: @Protrader_admin1');
});

// Auto-translate boshqa tillarda yozilganda
bot.on('text', async (ctx, next) => {
  const text = ctx.message.text;
  if (!text.match(/^[a-zA-Z0-9\s.,!?@#%&()+=:;'"]/)) {
    try {
      const res = await translate(text, { to: 'uz' });
      await ctx.reply(`🔄 Tahrim: ${res.text}`);
    } catch (e) {}
  }
  return next();
});

bot.launch();
